package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class OtherProfile extends AppCompatActivity {

    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_profile);
        id = getIntent().getIntExtra("id", 0);

        SQLiteOpenHelper userDatabaseHelper = new UserDatabaseHelper(this);
        try{
            SQLiteDatabase db = userDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query("USERS", new String[]{"NAME", "LOCATION", "STYLE"},
                    "_id = ?", new String[]{Integer.toString(id)}, null, null, null);
            if(cursor.moveToFirst()){
                String nameText = cursor.getString(0);
                String locationText = cursor.getString(1);
                String styleText = cursor.getString(2);

                TextView name = (TextView) findViewById(R.id.userTextView);
                name.setText(nameText);

                TextView location = (TextView) findViewById(R.id.locationName);
                location.setText(locationText);

                TextView style = (TextView) findViewById(R.id.styleName);
                style.setText(styleText);

            }
        }catch(SQLiteException e){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        FightButton();
        HomeButton();
    }

    public void FightButton() {

        Button button = (Button) findViewById(R.id.fightButton);

        final Intent intent = new Intent(this, Location.class);
        intent.putExtra("id", id);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    public void HomeButton() {

        Button button = (Button) findViewById(R.id.homeButton);

        final Intent intent = new Intent(this, Home.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }
}
