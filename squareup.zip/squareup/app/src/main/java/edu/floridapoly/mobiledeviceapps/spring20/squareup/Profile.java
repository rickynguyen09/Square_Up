package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Profile extends AppCompatActivity {

    private static final String EXTRA_NEW_USERS = "new_usersId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        HomeButton();
        //UserProfile();
        SharedProfile();
    }

    public void HomeButton() {
        Button button = (Button) findViewById(R.id.homeButton);

        final Intent intent = new Intent(this,Home.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }


    public void SharedProfile() {
        TextView yourAge = (TextView) findViewById(R.id.ageTextView);
        TextView yourGender = (TextView) findViewById(R.id.genderTextView);
        TextView yourLocation = (TextView) findViewById(R.id.locationTextView);
        TextView yourFightingStyle = (TextView) findViewById(R.id.fightingStyle);

        SharedPreferences result = PreferenceManager.getDefaultSharedPreferences(this);

        int saveAge = result.getInt("AGE", 0);
        if (saveAge == -1) {
            yourAge.setVisibility(View.GONE);
        }
        else {
            yourAge.setText("Age: " + saveAge);
        }

        /*String saveGender = result.getString("GENDER","");
        if (saveGender == null) {
            yourGender.setVisibility(View.GONE);
        }
        else {
            yourGender.setText("Gender: " + saveGender);
        }*/

        String saveLocation = result.getString("LOCATION","");
        if (saveLocation == null) {
            yourLocation.setVisibility(View.GONE);
        }
        else {
            yourLocation.setText("Location " + saveLocation);
        }

        String saveFightingStyle = result.getString("FIGHTING_STYLE","");
        if (saveFightingStyle == null) {
            yourFightingStyle.setVisibility(View.GONE);
        }
        else {
            yourFightingStyle.setText("Fighting Style: " + saveFightingStyle);
        }
    }

    /*public void UserProfile() {
        int new_usersId = (Integer)getIntent().getExtras().get(EXTRA_NEW_USERS);

        //Create a cursor
        SQLiteOpenHelper userDatabaseHelper = new UserDatabaseHelper(this);
        try {
            SQLiteDatabase db = userDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query ("NEW_USERS",
                    new String[] {"AGE", "GENDER", "LOCATION", "STYLE"},
                    "_id = ?",
                    new String[] {Integer.toString(new_usersId)},
                    null, null,null);
            //Move to the first record in the Cursor
            if (cursor.moveToFirst()) {
                //Get the NEW_USERS details from the cursor
                int ageText = cursor.getInt(7);
                //String genderButton = cursor.getString(8);
                String locationText = cursor.getString(4);
                String styleText = cursor.getString(5);

                //Populate the Age
                TextView age = (TextView)findViewById(R.id.ageTextView);
                age.setText(ageText);

                //Populate the Gender
                //TextView gender = (TextView)findViewById(R.id.genderTextView);
                //gender.setText(genderButton);

                //Populate the Location
                TextView location = (TextView) findViewById(R.id.locationTextView);
                location.setText(locationText);

                //Populate the Fighting Style
                TextView fightStyle = (TextView) findViewById(R.id.fightTextView);
                fightStyle.setText(styleText);
            }
        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }
    }*/
    public void Rating() {
        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
    }
}
