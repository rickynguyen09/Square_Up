package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Setting extends AppCompatActivity {

    public static final String EXTRA_LOCATIONID = "locationId";
    SQLiteOpenHelper userDatabaseHelper;
    SQLiteDatabase db;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        HomeButton();
        LogoutButton();
        GearBuy();
        HowToFight();
        //SeekerBarLocator();
    }

    public void HomeButton() {
        Button button = (Button) findViewById(R.id.homeButton);

        final Intent intent = new Intent(this,Home.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    public void LogoutButton() {
        Button button = (Button) findViewById(R.id.logoutButton);

        final Intent intent = new Intent(this,MainActivity.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    public void GearBuy() {
        TextView gearBuy = (TextView) findViewById(R.id.gearBuy);

        String createText = "Fighting Gears To Buy";

        Spannable ss = new SpannableString(createText);

        final Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.amazon.com/Macho-Martial-Arts-Sparring-Black/dp/B001T8E4AO/ref=sr_1_15?dchild=1&keywords=fighting%2Bgear&qid=1586294565&sr=8-15&th=1"));

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                startActivity(intent);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.GRAY);
            }
        };

        ss.setSpan(clickableSpan, 0,21, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        gearBuy.setText(ss);
        gearBuy.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void HowToFight() {
        TextView howToFight = (TextView) findViewById(R.id.howtToFight);

        String createText = "How to fight";

        Spannable ss = new SpannableString(createText);

        final Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/watch?v=GPSV3tg9Wig"));

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                startActivity(intent);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.GRAY);
            }
        };

        ss.setSpan(clickableSpan, 0,12, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        howToFight.setText(ss);
        howToFight.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void SeekerBarLocator() {
        final int min = 0;
        final int max = 100;
        final int[] current = {50};

        final TextView textView = (TextView) findViewById(R.id.numberLocationText);
        SeekBar seekBar = (SeekBar) findViewById(R.id.locationSeekBar);

        int locationId = (Integer)getIntent().getExtras().get(EXTRA_LOCATIONID);

        try {
            userDatabaseHelper = new UserDatabaseHelper(this);
            db = userDatabaseHelper.getReadableDatabase();
            cursor = db.query("USERS", new String[] {"RADIUS"}, "_id = ?",
                    new String[] {Integer.toString(locationId)}, null, null, null);

            if (cursor.moveToFirst()) {
                int location = cursor.getInt(0);

                seekBar.setProgress(location);
            }
        }
        catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        seekBar.setMax(max - min);
        seekBar.setProgress(current[0] - min);
        textView.setText("" + current[0]);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                current[0] = progress + min;
                textView.setText("" + current[0]);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {


            }
        });
    }
}
