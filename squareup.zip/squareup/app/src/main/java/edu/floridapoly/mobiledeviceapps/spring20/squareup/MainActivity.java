package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CreateAccount();
        Login();
    }

    public void CreateAccount() {

        TextView createAccount = findViewById(R.id.createAccount);

        String createText = "Create Account";

        SpannableString ss = new SpannableString(createText);

        final Intent intent = new Intent(this, CreateAccount.class);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                startActivity(intent);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.GRAY);
            }
        };

        ss.setSpan(clickableSpan, 0,14, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        createAccount.setText(ss);
        createAccount.setMovementMethod(LinkMovementMethod.getInstance());
    }

    //this needs work
    public void loginValidate() {

        EditText usernameText = findViewById(R.id.usernameText);
        EditText passwordText = findViewById(R.id.passwordText);

        String usernameNewText = usernameText.getText().toString();
        String passwordNewText = passwordText.getText().toString();


        Intent intent = new Intent(this, Profile.class);

        if(usernameNewText != "admin" && passwordNewText != "1234"){

            startActivity(intent);
        }
        else {

            Toast.makeText(this, "enter the username or password correctly", Toast.LENGTH_SHORT).show();
        }
    }

    public void Login() {

        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginValidate();
            }
        });
    }
}
