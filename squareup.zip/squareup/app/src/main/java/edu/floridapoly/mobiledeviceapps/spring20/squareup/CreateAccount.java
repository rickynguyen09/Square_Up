package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        ConfirmButton();
    }

    public void ConfirmButton() {
        Button button = (Button) findViewById(R.id.confirmButton);

        final Intent intent = new Intent(this,Profile.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonClicked();
            }
        });
    }

    public void radioButtonClicked() {

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        RadioButton maleRadioButton = (RadioButton) findViewById(R.id.maleRadioButton);
        RadioButton femaleRadioButton = (RadioButton) findViewById(R.id.femaleRadioButton);

        if(radioGroup.getCheckedRadioButtonId() == -1){
            Toast.makeText(this, "Choose the gender",Toast.LENGTH_SHORT).show();
        }
        else if(maleRadioButton.isChecked())
        {
            insertMaleNewUser();
        }
        else if(femaleRadioButton.isChecked())
        {
            insertFemaleNewUser();
        }
    }

    public void insertMaleNewUser(){

        //UserDatabaseHelper db = new UserDatabaseHelper(this);

        EditText userNameText = (EditText) findViewById(R.id.createUserNameText);
        EditText passwordText = (EditText) findViewById(R.id.createPasswordText);
        EditText nameText = (EditText) findViewById(R.id.createName);
        EditText emailText = (EditText) findViewById(R.id.createEmailText);
        EditText locationText = (EditText) findViewById(R.id.createLocationText);
        EditText fightingStyle = (EditText) findViewById(R.id.createFightingStyle);
        EditText radiusText = (EditText) findViewById(R.id.createRadius);
        EditText ageText = (EditText) findViewById(R.id.createAge);

        /*RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) findViewById(radioId);*/

        //int ageNewText = Integer.parseInt(ageText.getText().toString());
        String locationNewText = locationText.getText().toString();
        String fightingNewStyle = fightingStyle.getText().toString();

        Intent intent = new Intent(this,Profile.class);

        // set SharedPreferences
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        //editor.putString("AGE", String.valueOf(ageNewText));
        editor.putString("LOCATION", locationNewText);
        editor.putString("FIGHTING_STYLE",fightingNewStyle);

        editor.commit();


                /*boolean isInserted = db.insertNewUser(userNameText.getText().toString(), passwordText.getText().toString(),
                        nameText.getText().toString(), emailText.getText().toString(),
                        locationText.getText().toString(), fightingStyle.getText().toString(),
                        Integer.valueOf(radiusText.getText().toString()), Integer.valueOf(ageText.getText().toString()),
                        radioButton.getText().toString()
                        );
                if(isInserted = true){
                    Toast.makeText(CreateAccount.this, "Data Inserted",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(CreateAccount.this, "Data not Inserted", Toast.LENGTH_SHORT).show();
                }*/

        startActivity(intent);
    }

    public void insertFemaleNewUser() {

        //UserDatabaseHelper db = new UserDatabaseHelper(this);

        EditText userNameText = (EditText) findViewById(R.id.createUserNameText);
        EditText passwordText = (EditText) findViewById(R.id.createPasswordText);
        EditText nameText = (EditText) findViewById(R.id.createName);
        EditText emailText = (EditText) findViewById(R.id.createEmailText);
        EditText locationText = (EditText) findViewById(R.id.createLocationText);
        EditText fightingStyle = (EditText) findViewById(R.id.createFightingStyle);
        EditText radiusText = (EditText) findViewById(R.id.createRadius);
        EditText ageText = (EditText) findViewById(R.id.createAge);

        /*RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) findViewById(radioId);*/

        String ageNewText = ageText.getText().toString();
        //int ageNewText = Integer.parseInt(ageText.getText().toString());
        String locationNewText = locationText.getText().toString();
        String fightingNewStyle = fightingStyle.getText().toString();

        Intent intent = new Intent(this,Profile.class);

        // set SharedPreferences
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt("AGE", 23);
        editor.putString("LOCATION", locationNewText);
        editor.putString("FIGHTING_STYLE", fightingNewStyle);

        editor.commit();

        startActivity(intent);
    }
}
