package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

    SQLiteOpenHelper userDatabaseHelper;

    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        SettingButton();
        HomeButton();
        NotificationButton();
        UserListView();
    }

    public void SettingButton() {

        Button button = (Button) findViewById(R.id.settingButton);

        final Intent intent = new Intent(this,Setting.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    public void HomeButton() {
        Button button = (Button) findViewById(R.id.profileButton);

        final Intent intent = new Intent(this, Profile.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    public void NotificationButton() {
        Button button = (Button) findViewById(R.id.notificationButton);

        final Intent intent = new Intent(this, Notification.class);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "This is a Notification Example";
                NotificationCompat.Builder builder = new NotificationCompat.Builder(
                        Home.this
                )
                        .setSmallIcon(R.drawable.ic_whatshot)
                        .setContentTitle("New Notification")
                        .setContentText(message)
                        .setAutoCancel(true);

                Intent intent = new Intent(Home.this,
                        Notification.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("message", message);

                PendingIntent pendingIntent = PendingIntent.getActivity(Home.this,
                        0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                NotificationManager notificationManager = (NotificationManager)getSystemService(
                        Context.NOTIFICATION_SERVICE
                );
                notificationManager.notify(0, builder.build());

                startActivity(intent);
            }
        });
    }

    public void UserListView() {

        ListView listView = (ListView)findViewById(R.id.listView);


        try {
            userDatabaseHelper = new UserDatabaseHelper(this);
            db = userDatabaseHelper.getReadableDatabase();
            cursor = db.query("USERS", new String[]{"_id", "NAME"},
                    null, null, null, null, null);
            SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,
                    cursor, new String[]{"NAME"}, new int[]{android.R.id.text1}, 0);
            listView.setAdapter(listAdapter);
        }catch(SQLiteException e){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        final Intent intent = new Intent(this,OtherProfile.class);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                intent.putExtra("id", position + 1);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        cursor.close();
        db.close();
    }
}
