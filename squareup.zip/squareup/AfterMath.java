package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class AfterMath extends AppCompatActivity {

    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_math);

        id = getIntent().getIntExtra("id", 0);

        SQLiteOpenHelper userDatabaseHelper = new UserDatabaseHelper(this);
        try{
            SQLiteDatabase db = userDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query("USERS", new String[]{"NAME"},
                    "_id = ?", new String[]{Integer.toString(id)}, null, null, null);
            if(cursor.moveToFirst()){
                String nameText = cursor.getString(0);

                TextView name = (TextView) findViewById(R.id.userTextView);
                name.setText(nameText);
            }
        }catch(SQLiteException e){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        ConfirmButton();
    }

    public void radioButtonClicked() {

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        RadioButton rateRadioButton = (RadioButton) findViewById(R.id.rateRadioButton);
        RadioButton reportRadioButton = (RadioButton) findViewById(R.id.reportRadioButton);

        Intent intent = new Intent(this, Home.class);

        if (radioGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Choose either Rate or Report", Toast.LENGTH_SHORT).show();
        }
        else if(rateRadioButton.isChecked()) {
            RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar2);


        }
        else if(reportRadioButton.isChecked()) {
            Toast.makeText(this, "User is reported", Toast.LENGTH_SHORT).show();
        }

        startActivity(intent);
    }

    public void ConfirmButton() {

        Button button = (Button) findViewById(R.id.confirmButton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonClicked();
            }
        });


    }
}
