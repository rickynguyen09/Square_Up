package edu.floridapoly.mobiledeviceapps.spring20.squareup;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "users";
    private static final int DB_VERSION = 1;

    UserDatabaseHelper(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE USERS (_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "USERNAME TEXT," +
                "PASSWORD TEXT," +
                "NAME TEXT," +
                "EMAIL TEXT," +
                "LOCATION TEXT," +
                "STYLE TEXT," +
                "RADIUS INTEGER," +
                "AGE INTEGER," +
                "GENDER TEXT);");
        insertUser(db, "HornedBull87", "Texas4Evar", "Johnathan Montana",
                "texasbull1987@gmail.com", "San Antonio, Texas", "Fists", 10, 32, "M");
        insertUser(db, "zack123", "bettertwin", "Zack Martin",
                "gotthesuitelife@gmail.com", "Boston, Massachusetts", "Fists", 100, 22, "M");
        insertUser(db, "choconut19", "PunchyPunchPunch", "Jackie Quinta",
                "fightclub2000@aol.com", "Madrid, Spain", "Fists", 12, 20, "F");
        insertUser(db, "mmmmmmq", "123xXx321", "Beau LeFrancois",
                "croissantboy@hotmail.com", "Paris, France", "Swords", 2, 26, "M");
        insertUser(db, "BoBoBoBoBoBo", "888eight888", "Melissa Xavier",
                "xavierm@yahoo.com", "Portland, Oregon", "Guns", 5, 19, "F");
        insertUser(db, "Agent007", "G0ld3n3y3", "James Bond",
                "bjames@aol.com", "London, UK", "Fists", 30, 37, "M");
        insertUser(db, "St4rL0rd", "g4m0r4", "Peter Quill",
                "galaxyguardian1@gmail.com", "St Charles, Missouri", "Fists", 8, 40, "M");
        insertUser(db, "PianoMan49", "DownEAlexa", "Billy Joel",
                "didntstartthefire@yahoo.com", "New York, New York", "Fists", 4, 70, "M");
        insertUser(db, "xx_epicgamer_xx", "epicfortnite", "Richard Blevins",
                "ninjafortnite@outlook.com", "Detroit, Michigan", "Guns", 15, 28, "M");
        insertUser(db, "SpaceBounty", "metroid86", "Samus Aran",
                "piratedestroyer@gmail.com", "Kyoto, Japan", "Guns", 70, 30, "F");
        insertUser(db, "TombTracker", "risingagain", "Lara Croft",
                "shadowofthetomb@gmail.com", "Manchester, UK", "Guns", 44, 23, "F");
        insertUser(db, "DudeRaider", "elGDdorado", "Nathan Drake",
                "unchartedgold@yahoo.com", "New Orleans, Louisiana", "Guns", 60, 38, "M");
        insertUser(db, "RichBoy88", "ca$hmoney", "Timothy McMoney",
                "loadsofmoney@aol.com", "Tampa, Florida", "Swords", 21, 29, "M");
        insertUser(db, "BigSmoke", "2number9s", "Melvin Harris",
                "number9large@outlook.com", "San Andreas, California", "Bats", 18, 27, "M");
        insertUser(db, "JumpMan", "w4h00!!", "Mario Mario",
                "mushroomplumber@aol.com", "Brooklyn, New York", "Fists", 88, 37, "M");
        insertUser(db, "Mang0", "1v1foxonly", "Joseph Marquez",
                "smashbrosmelee@hotmail.com", "Norwalk, California", "Fists", 39, 28, "M");
        insertUser(db, "ShrekLover420", "shrekislove&life", "Francis Weirdo",
                "ogreslikeonions@gmail.com", "Glendale, California", "Swords", 69, 24, "M");
        insertUser(db, "IAmSpeed", "rusteezracer", "Lightning McQueen",
                "kerchowrace@yahoo.com", "Nashville, Tennessee", "Fists", 66, 44, "M");
        insertUser(db, "DraculaBackwards", "symphonyOTN", "Alucard Tepes",
                "whatisaman@outlook.com", "Bran Castle, Romania", "Fists", 28, 100, "M");
        insertUser(db, "LastJedi", "palpgrandkid", "Rey Skywalker",
                "theforceawakens@aol.com", "Burbank, California", "Fists", 40, 27, "F");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }

    public void insertUser(SQLiteDatabase db, String username, String password, String name, String email,
                           String location, String style, int radius, int age, String gender){
        ContentValues values = new ContentValues();
        values.put("USERNAME", username);
        values.put("PASSWORD", password);
        values.put("NAME", name);
        values.put("EMAIL", email);
        values.put("LOCATION", location);
        values.put("STYLE", style);
        values.put("RADIUS", radius);
        values.put("AGE", age);
        values.put("GENDER", gender);
        db.insert("USERS", null, values);
    }

    public void updateLocationView(int radius){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("RADIUS", radius);

        db.update("USERS",values,null,null);
    }
}
